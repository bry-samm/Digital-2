/*
 * CONF_ADC.h
 *
 * Created: 8/05/2025 15:37:38
 *  Author: bsmor
 */ 


#ifndef CONF_ADC_H_
#define CONF_ADC_H_


void initADC();


#endif /* CONF_ADC_H_ */