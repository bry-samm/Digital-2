/*
 * initUART.h
 *
 * Created: 27/01/2026 00:03:08
 *  Author: bsmor
 */ 


#ifndef INITUART_H_
#define INITUART_H_

void initUART();


#endif /* INITUART_H_ */