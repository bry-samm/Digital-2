/*
 * initUART.h
 *
 * Created: 27/01/2026 00:03:08
 *  Author: bsmor
 */ 


#ifndef INITUART_H_
#define INITUART_H_

void initUART();
void writeChar(char caracter);
void cadena_texto(char* texto);


#endif /* INITUART_H_ */