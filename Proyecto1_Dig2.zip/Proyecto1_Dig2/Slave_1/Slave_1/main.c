/*
 * Slave_1.c
 * 
 * Created:
 * Author:
 */
//************************************************************************************
//================================== ESCLAVO 1 =====================================
//Este eslavo tiene la funci�n de realizar la lectura para el MPU680
//*************************************************************************************
//Recordar que siempre hay que poner una resistencia pull-up 
// Para ver conexi�n (ver grabaci�n clase 1:15:16)
// Para calcular valor (ver modulos de clase)

// Encabezado (librer�as)
#include <avr/io.h>
#include <stdint.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "I2C_conf.h"

//Se define la direcci�n del esclavo, en este caso como es mi programa yo decido que direcci�n tiene
// caso contrario cuando se trabaja con un sensor, se debe de colocar la direcci�n descrita por el datasheet del sensor
#define SlaveAddress 0x30

uint8_t buffer = 0;
uint8_t valor_ADC;

//************************************************************************************
// Function prototypes

//************************************************************************************
// Main Function
int main(void)
{
	DDRB |= (1 << DDB5);
	PORTB &= ~(1 << PORTB5); //Led para encender y apgar indicando una comunicaci�n exitosa
	
	//inicializar ADC
	I2C_Slave_Init(SlaveAddress); //Se define la direcci�n del esclavo
	sei(); //Habilitar interrupciones
	
	while (1)
	{
		if(buffer == 'R'){ //Reviso si el caract�r de lectura esta recibiendose
			PINB |= (1 << PINB5); //Se hace un toggle para indicar que si hay datos 
			buffer = 0;
		}
		//Iniciar la secuencia de ADC
	}
}

//************************************************************************************
// NON-INterrupt subroutines

//************************************************************************************
// Interrupt subroutines
ISR(TWI_vect){
	uint8_t estado = TWSR & 0xFC; //Nos quedamos unicamente con los bits de estado TWI Status
	switch(estado){
		//**************************
		// Slave debe recibir dato
		//**************************
		case 0x60: //SLA+W recibido
		case 0x70: //General call
			TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE); //Indica "si te escuche"
			break;
		
		case 0x80: //Dato recibido, ACK enviado
		case 0x90: //Dato recibido General call, ACK enviado
			buffer = TWDR; //Ya puedo utilizar los datos
			TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
			break;
		//*****************************
		// Slave debe transmitir dato
		//*****************************
		//en cada case hay un comando que ya est� predeterminado (ver presentacion)
		case 0xA8: //SLA+R recibido
		case 0xB8: //Dato transmitido, ACK recibido
			TWDR = valorADC; //Dato a enviar
			TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
			break;
		//IMPORTANTE: que pasa si quiero enviar m�s de un dato?
		//Se puede hacer un arreglo por cada vez que env�o un dato (ver grabaci�n clase 1:08:11)
		
		case 0xC0: //Dato transmitido, NACK recibido
		case 0xC8: //�ltimo dato transmitido
			TWCR = 0; //Limpio la interfaz para rebibir nuevo dato
			TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN); //Reiniciarse
			break;
			
		case 0xA0: // STOP o repeated START recibido como slave
			TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
			break;
		//**********************
		// Cualquier error
		//**********************
		default:
			TWCR = (1 << TWINT) | (1 << TWEA) | (1 << TWEN) | (1 << TWIE);
			break;
		
	}
	
}